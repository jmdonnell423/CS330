Starting with the OpenGLSample project, make the following changes:

1. Place the egg.jpg and marble.jpg inside the folder with your source code.
2. Place all .h and .cpp files in your folder where source.cpp is.
3. If your project uses source.cpp, my source.cpp should replace yours (make sure you copy the code in your source.cpp and back it up).
4. Don't forget to add the 3 .h files to your project in the Solution Explorer under header files folder.
5. Don't forget to add the shapegenerator.cpp file to the Source Files in the Solution Explorer.